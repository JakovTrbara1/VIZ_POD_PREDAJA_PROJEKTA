d3.json("data/streamingHistory_music_0.json", function (error, rawData) {
    if (error) throw error;

    const heatmapData = Array.from({ length: 7 }, () => Array(24).fill(0));

    rawData.forEach(d => {
        const rawDate = d.endTime || d.ts;
        const date = new Date(rawDate);
        const day = date.getDay();
        const hour = date.getHours();
        const minutes = (d.msPlayed || d.ms_played || 0) / 60000;
        heatmapData[day][hour] += minutes;
    });

    const margin = { top: 60, right: 20, bottom: 70, left: 60 },
        width = 800 - margin.left - margin.right,
        height = 300 - margin.top - margin.bottom,
        cellSize = Math.floor(width / 24);

    const maxValue = d3.max(heatmapData.flat());

    const colorScale = d3.scale.linear()
        .domain([0, maxValue])
        .range(["#1b1b1b", "#1db954"]);

    const svg = d3.select("#listening-heatmap-chart")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom + 60)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    // Animated cells
    const cell = svg.selectAll(".cell")
        .data(d3.merge(heatmapData.map((row, rowIndex) =>
            row.map((value, colIndex) => ({
                row: rowIndex,
                col: colIndex,
                value
            }))
        )))
        .enter().append("g")
        .attr("class", "cell");

    cell.append("rect")
        .attr("x", d => d.col * cellSize)
        .attr("y", d => d.row * cellSize)
        .attr("width", cellSize)
        .attr("height", cellSize)
        .style("fill", "#1b1b1b")
        .transition()
        .duration(800)
        .style("fill", d => colorScale(d.value));

    // Tooltip-like title on hover
    cell.append("title")
        .text(d => `${days[d.row]} ${d.col}:00 - ${Math.round(d.value)} min`);

    // Optional text inside cells
    cell.append("text")
        .text(d => d.value >= 1 ? Math.round(d.value) : "")
        .attr("x", d => d.col * cellSize + cellSize / 2)
        .attr("y", d => d.row * cellSize + cellSize / 2)
        .attr("text-anchor", "middle")
        .attr("dy", ".35em")
        .style("fill", "#fff")
        .style("font-size", "9px");

    // Day labels
    svg.selectAll(".dayLabel")
        .data(days)
        .enter()
        .append("text")
        .text(d => d)
        .attr("x", -10)
        .attr("y", (d, i) => i * cellSize + cellSize / 1.5)
        .style("text-anchor", "end")
        .style("fill", "#fff")
        .style("font-size", "12px");

    // Hour labels
    svg.selectAll(".hourLabel")
        .data(d3.range(24))
        .enter()
        .append("text")
        .text(d => d)
        .attr("x", d => d * cellSize + cellSize / 2)
        .attr("y", -5)
        .style("text-anchor", "middle")
        .style("fill", "#fff")
        .style("font-size", "10px");

    // Color legend
    const legendWidth = 200;
    const legendHeight = 10;
    const legendMargin = 30;

    const defs = svg.append("defs");
    const linearGradient = defs.append("linearGradient")
        .attr("id", "heatmap-gradient");

    linearGradient.selectAll("stop")
        .data([
            { offset: "0%", color: "#1b1b1b" },
            { offset: "100%", color: "#1db954" }
        ])
        .enter().append("stop")
        .attr("offset", d => d.offset)
        .attr("stop-color", d => d.color);

    const legendYOffset = 25;

    svg.append("rect")
        .attr("x", (width - legendWidth) / 2)
        .attr("y", height + legendMargin + legendYOffset)
        .attr("width", legendWidth)
        .attr("height", legendHeight)
        .style("fill", "url(#heatmap-gradient)");

    const legendScale = d3.scale.linear()
        .domain([0, maxValue])
        .range([(width - legendWidth) / 2, (width + legendWidth) / 2]);

    const legendAxis = d3.svg.axis()
        .scale(legendScale)
        .orient("bottom")
        .ticks(5)
        .tickFormat(d => Math.round(d));

    svg.append("g")
        .attr("class", "legend axis")
        .attr("transform", `translate(0, ${height + legendMargin + legendYOffset + legendHeight})`)
        .call(legendAxis)
        .selectAll("text")
        .style("fill", "#ccc")
        .style("font-size", "10px");


    svg.append("text")
        .attr("x", width / 2)
        .attr("y", height + legendMargin + legendYOffset + legendHeight + 30) // was 20
        .attr("text-anchor", "middle")
        .style("fill", "#fff")
        .style("font-size", "12px")
        .text("Minutes");


});
