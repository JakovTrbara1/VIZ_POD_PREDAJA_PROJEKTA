function renderArtistChart(data) {
    const margin = { top: 20, right: 20, bottom: 40, left: 250 };
    const width = 900 - margin.left - margin.right;
    const height = data.length * 35;

    const svg = d3.select("#top-artists-chart")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    const x = d3.scale.linear()
        .domain([0, d3.max(data, d => d.values)])
        .range([0, width]);

    const y = d3.scale.ordinal()
        .domain(data.map(d => d.key))
        .rangeRoundBands([0, height], 0.2);

    const xAxis = d3.svg.axis().scale(x).orient("bottom").ticks(5).tickFormat(d => `${Math.round(d / 60000)} `);
    const yAxis = d3.svg.axis().scale(y).orient("left");

    svg.append("g")
        .attr("class", "x axis")
        .attr("transform", `translate(0,${height})`)
        .call(xAxis)
        .append("text")
        .attr("x", width / 2)
        .attr("y", 35)
        .style("text-anchor", "middle")
        .style("fill", "#ccc")
        .text("Listening Time (minutes)");

    svg.append("g")
        .attr("class", "y axis")
        .call(yAxis);

    const tooltip = d3.select("body").append("div")
        .attr("class", "tooltip")
        .style("opacity", 0);

    const bars = svg.selectAll(".bar")
        .data(data)
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("y", d => y(d.key))
        .attr("height", y.rangeBand())
        .attr("x", 0)
        .attr("width", 0)
        .style("opacity", 0)
        .attr("fill", "#1db954")
        .on("mouseover", function (event, d) {
            tooltip.transition().duration(200).style("opacity", 0.9);
            tooltip.html(`<strong>${d.key}</strong><br>${Math.round(d.values / 60000)}`)
                .style("left", (event.pageX + 10) + "px")
                .style("top", (event.pageY - 30) + "px");
            d3.select(this).attr("fill", "#1ed760");
        })
        .on("mouseout", function () {
            tooltip.transition().duration(200).style("opacity", 0);
            d3.select(this).attr("fill", "#1db954");
        });

    const labels = svg.selectAll(".label")
        .data(data)
        .enter()
        .append("text")
        .attr("x", 0)
        .attr("y", d => y(d.key) + y.rangeBand() / 2)
        .attr("dy", ".35em")
        .attr("fill", "white")
        .style("opacity", 0)
        .text(d => `${Math.round(d.values / 60000)} `);

    const section = document.querySelector("#top-artists");

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                bars.transition()
                    .duration(800)
                    .delay((d, i) => i * 100)
                    .attr("width", d => x(d.values))
                    .style("opacity", 1);

                labels.transition()
                    .duration(800)
                    .delay((d, i) => i * 100 + 400)
                    .attr("x", d => x(d.values) + 5)
                    .style("opacity", 1);

                observer.disconnect();
            }
        });
    }, { threshold: 0.5 });

    observer.observe(section);
}

d3.json("data/streamingHistory_music_0.json", function (error, rawData) {
    if (error) throw error;

    const artistStats = d3.nest()
        .key(d => d.artistName || d.master_metadata_album_artist_name || "Unknown Artist")
        .rollup(v => d3.sum(v, d => d.msPlayed || d.ms_played))
        .entries(rawData)
        .filter(d => d.key !== "Unknown Artist")
        .sort((a, b) => d3.descending(a.values, b.values))
        .slice(0, 10);

    renderArtistChart(artistStats);
});
