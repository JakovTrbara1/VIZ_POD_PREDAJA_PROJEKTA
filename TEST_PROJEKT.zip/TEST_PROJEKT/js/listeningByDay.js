function renderListeningByDay(rawData) {
  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const totals = Array(7).fill(0);

  rawData.forEach(d => {
    const date = new Date(d.ts || d.endTime);
    const day = date.getDay();
    totals[day] += (d.msPlayed || d.ms_played || 0) / 60000;
  });

  const data = days.map((day, i) => ({ day, minutes: Math.round(totals[i]) }));

  const margin = { top: 20, right: 20, bottom: 40, left: 60 };
  const width = 900 - margin.left - margin.right;
  const height = 400;

  const svg = d3.select("#listening-by-day-chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const x = d3.scale.ordinal()
    .domain(days)
    .rangeBands([0, width], 0.1);

  const y = d3.scale.linear()
    .domain([0, d3.max(data, d => d.minutes)])
    .range([height, 0]);

  svg.append("g")
    .attr("class", "x axis")
    .attr("transform", `translate(0,${height})`)
    .call(d3.svg.axis().scale(x).orient("bottom"))
    .append("text")
    .attr("x", width / 2)
    .attr("y", 35)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Day of Week");

  svg.append("g")
    .attr("class", "y axis")
    .call(d3.svg.axis().scale(y).orient("left"))
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", -50)
    .attr("x", -height / 2)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Listening Time (minutes)");

  svg.selectAll(".bar")
    .data(data)
    .enter()
    .append("rect")
    .attr("x", d => x(d.day))
    .attr("y", height)
    .attr("width", x.rangeBand())
    .attr("height", 0)
    .attr("fill", "#1db954")
    .transition()
    .duration(800)
    .delay((d, i) => i * 50)
    .attr("y", d => y(d.minutes))
    .attr("height", d => height - y(d.minutes));
}

function initListeningByDay() {
  d3.json("data/streamingHistory_music_0.json", function (error, rawData) {
    if (error) throw error;
    const section = document.querySelector("#listening-by-day");
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        renderListeningByDay(rawData);
        observer.disconnect();
      }
    }, { threshold: 0.3 });
    observer.observe(section);
  });
}

initListeningByDay();
