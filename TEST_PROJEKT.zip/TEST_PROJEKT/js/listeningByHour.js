function renderListeningByHour(rawData) {
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const hourTotals = Array(24).fill(0);

  rawData.forEach(d => {
    const rawDate = d.ts || d.endTime;
    const time = rawDate.includes("T") ? rawDate.split("T")[1] : rawDate.split(" ")[1];
    const hour = parseInt(time.split(":")[0]);
    hourTotals[hour] += (d.msPlayed || d.ms_played || 0) / 60000;
  });

  const data = hours.map(h => ({ hour: h, minutes: Math.round(hourTotals[h]) }));

  const margin = { top: 20, right: 20, bottom: 40, left: 60 };
  const width = 900 - margin.left - margin.right;
  const height = 400;

  const svg = d3.select("#listening-by-hour-chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const x = d3.scale.ordinal()
    .domain(hours)
    .rangeBands([0, width], 0.1);

  const y = d3.scale.linear()
    .domain([0, d3.max(data, d => d.minutes)])
    .range([height, 0]);

  svg.append("g")
    .attr("class", "x axis")
    .attr("transform", `translate(0,${height})`)
    .call(d3.svg.axis().scale(x).orient("bottom").tickFormat(d => `${d}:00`))
    .append("text")
    .attr("x", width / 2)
    .attr("y", 35)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Hour of Day");

  svg.append("g")
    .attr("class", "y axis")
    .call(d3.svg.axis().scale(y).orient("left"))
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", -50)
    .attr("x", -height / 2)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Listening Time (minutes)");

  svg.selectAll(".bar")
    .data(data)
    .enter()
    .append("rect")
    .attr("x", d => x(d.hour))
    .attr("y", height)
    .attr("width", x.rangeBand())
    .attr("height", 0)
    .attr("fill", "#1db954")
    .transition()
    .duration(800)
    .delay((d, i) => i * 50)
    .attr("y", d => y(d.minutes))
    .attr("height", d => height - y(d.minutes));
}

function initListeningByHour() {
  d3.json("data/streamingHistory_music_0.json", function (error, rawData) {
    if (error) throw error;
    const section = document.querySelector("#listening-by-hour");
    const observer = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        renderListeningByHour(rawData);
        observer.disconnect();
      }
    }, { threshold: 0.3 });
    observer.observe(section);
  });
}

initListeningByHour();
