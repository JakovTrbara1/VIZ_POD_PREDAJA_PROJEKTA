function drawListeningOverTime(rawData) {
  if (d3.select("#listening-over-time-chart svg").node()) return; // Prevent duplicate

  const dataByDay = {};
  rawData.forEach(d => {
    const rawDate = d.ts || d.endTime || null;
    if (!rawDate) return;
    const dateStr = rawDate.includes("T") ? rawDate.split("T")[0] : rawDate.split(" ")[0];
    dataByDay[dateStr] = (dataByDay[dateStr] || 0) + (d.msPlayed || d.ms_played || 0);
  });

  const data = Object.keys(dataByDay).map(date => ({
    date: new Date(date),
    minutes: Math.round(dataByDay[date] / 60000)
  })).sort((a, b) => a.date - b.date);

  const margin = { top: 20, right: 20, bottom: 60, left: 60 };
  const width = 900 - margin.left - margin.right;
  const height = 400;

  const svg = d3.select("#listening-over-time-chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const x = d3.time.scale().domain(d3.extent(data, d => d.date)).range([0, width]);
  const y = d3.scale.linear().domain([0, d3.max(data, d => d.minutes)]).range([height, 0]);

  const xAxis = d3.svg.axis().scale(x).orient("bottom").ticks(10);
  const yAxis = d3.svg.axis().scale(y).orient("left");

  svg.append("g")
    .attr("class", "x axis")
    .attr("transform", `translate(0,${height})`)
    .call(xAxis)
    .append("text")
    .attr("x", width / 2)
    .attr("y", 40)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Date");

  svg.append("g")
    .attr("class", "y axis")
    .call(yAxis)
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", -50)
    .attr("x", -height / 2)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Listening Time (minutes)");

  const line = d3.svg.line()
    .x(d => x(d.date))
    .y(d => y(d.minutes));

  const path = svg.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "#1db954")
    .attr("stroke-width", 2)
    .attr("d", line);

  const totalLength = path.node().getTotalLength();

  path
    .attr("stroke-dasharray", totalLength + " " + totalLength)
    .attr("stroke-dashoffset", totalLength)
    .transition()
    .duration(1000)
    .ease("linear")
    .attr("stroke-dashoffset", 0);
}

function initListeningOverTime() {
  d3.json("data/streamingHistory_music_0.json", function (error, rawData) {
    if (error) throw error;

    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          drawListeningOverTime(rawData);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.3 });

    const section = document.querySelector("#listening-over-time-chart");
    if (section) observer.observe(section);
  });
}

initListeningOverTime();
