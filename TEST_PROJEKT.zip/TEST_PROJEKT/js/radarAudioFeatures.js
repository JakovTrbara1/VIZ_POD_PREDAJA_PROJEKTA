function renderRadarChart(features) {
  const containerId = "#audio-features-radar";
  d3.select(containerId).selectAll("*").remove();

  const w = 400, h = 400;
  const radius = Math.min(w, h) / 2 - 50;
  const levels = 5;
  const angleSlice = (2 * Math.PI) / 8;
  const featureKeys = ["danceability", "energy", "valence", "acousticness", "instrumentalness", "liveness", "speechiness", "tempo"];

  const featureData = featureKeys.map((key, i) => ({
    axis: key.charAt(0).toUpperCase() + key.slice(1),
    value: key === "tempo" ? Math.min(features.tempo / 250, 1) : parseFloat(features[key])
  }));

  const svg = d3.select(containerId)
    .append("svg")
    .attr("width", w)
    .attr("height", h)
    .append("g")
    .attr("transform", `translate(${w / 2}, ${h / 2})`);

  for (let lvl = 0; lvl < levels; lvl++) {
    const r = radius * ((lvl + 1) / levels);
    svg.append("polygon")
      .attr("points", featureData.map((d, i) => {
        const angle = i * angleSlice - Math.PI / 2;
        return `${Math.cos(angle) * r},${Math.sin(angle) * r}`;
      }).join(" "))
      .attr("fill", "none")
      .attr("stroke", "#aaa")
      .attr("stroke-width", "1px")
      .attr("opacity", 0.3);
  }

  featureData.forEach((d, i) => {
    const angle = i * angleSlice - Math.PI / 2;
    svg.append("line")
      .attr("x1", 0).attr("y1", 0)
      .attr("x2", Math.cos(angle) * radius)
      .attr("y2", Math.sin(angle) * radius)
      .attr("stroke", "#999");

    svg.append("text")
      .attr("x", Math.cos(angle) * (radius + 15))
      .attr("y", Math.sin(angle) * (radius + 15))
      .attr("text-anchor", "middle")
      .attr("fill", "#fff")
      .style("font-size", "12px")
      .text(d.axis);
  });

  const radarLine = d3.svg.line.radial()
    .radius(d => d.value * radius)
    .angle((d, i) => i * angleSlice)
    .interpolate("linear-closed");

  const initialData = featureData.map(d => ({ ...d, value: 0 }));

  const path = svg.append("path")
    .datum(initialData)
    .attr("fill", "#1db954")
    .attr("stroke", "#1db954")
    .attr("fill-opacity", 0.6)
    .attr("stroke-width", 2)
    .attr("d", radarLine);

  path.transition()
    .duration(800)
    .attrTween("d", function () {
      const interpolate = d3.interpolateArray(initialData, featureData);
      return function (t) {
        return radarLine(interpolate(t));
      };
    });

  featureData.forEach((d, i) => {
    const angle = i * angleSlice - Math.PI / 2;
    const r = d.value * radius;
    svg.append("circle")
      .attr("cx", 0)
      .attr("cy", 0)
      .attr("r", 4)
      .attr("fill", "#1db954")
      .attr("stroke", "#fff")
      .attr("stroke-width", 1.5)
      .transition()
      .duration(800)
      .attr("cx", Math.cos(angle) * r)
      .attr("cy", Math.sin(angle) * r);
  });
}

window.renderRadarChart = renderRadarChart;
