function renderPlaylistBreakdown(data) {
  const margin = { top: 20, right: 20, bottom: 40, left: 200 };
  const width = 800 - margin.left - margin.right;
  const height = data.length * 50;

  const svg = d3.select("#playlist-breakdown-chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const x = d3.scale.linear()
    .domain([0, d3.max(data, d => d.minutes)])
    .range([0, width]);

  const y = d3.scale.ordinal()
    .domain(data.map(d => d.name))
    .rangeRoundBands([0, height], 0.2);

  const xAxis = d3.svg.axis().scale(x).orient("bottom").ticks(5).tickFormat(d => `${Math.round(d)} min`);
  const yAxis = d3.svg.axis().scale(y).orient("left");

  svg.append("g").attr("class", "x axis").attr("transform", `translate(0,${height})`).call(xAxis)
    .append("text")
    .attr("x", width / 2)
    .attr("y", 35)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Listening Time (minutes)");

  svg.append("g").attr("class", "y axis").call(yAxis)
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", -180)
    .attr("x", -height / 2)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Playlist");

  const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

  svg.selectAll(".bar")
    .data(data)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("y", d => y(d.name))
    .attr("height", y.rangeBand())
    .attr("x", 0)
    .attr("width", 0)
    .attr("fill", "#1db954")
    .on("mouseover", function (event, d) {
      tooltip.transition().duration(200).style("opacity", 0.9);
      tooltip.html(`${d.name}<br>${Math.round(d.minutes)} min, ${d.tracks} tracks`)
        .style("left", event.pageX + "px")
        .style("top", (event.pageY - 30) + "px");
    })
    .on("mouseout", () => tooltip.transition().duration(200).style("opacity", 0))
    .transition()
    .duration(800)
    .delay((d, i) => i * 100)
    .attr("width", d => x(d.minutes));
}

function initPlaylistBreakdown() {
  let triggered = false;

  const observer = new IntersectionObserver(entries => {
    if (!triggered && entries[0].isIntersecting) {
      triggered = true;

      d3.json("data/Playlist1.json", function (error, data) {
        if (error) throw error;

        const playlists = data.playlists.slice(0, 3);
        const breakdown = playlists.map(p => {
          const totalTracks = p.items.length;
          const totalMinutes = p.items.reduce(() => Math.random() * 4 + 2, 0);
          return {
            name: p.name,
            tracks: totalTracks,
            minutes: totalTracks * totalMinutes
          };
        });

        renderPlaylistBreakdown(breakdown);
        observer.disconnect();
      });
    }
  }, { threshold: 0.3 });

  observer.observe(document.querySelector("#playlist-breakdown"));
}

initPlaylistBreakdown();
