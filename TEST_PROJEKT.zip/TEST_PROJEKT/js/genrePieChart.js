function renderGenrePieChart() {
  const genreData = [
    { genre: 'Metal', count: 7 },
    { genre: 'Country', count: 6 },
    { genre: 'Pop', count: 3 },
    { genre: 'Folk', count: 2 },
    { genre: 'Jazz', count: 2 },
    { genre: 'Electronic', count: 2 },
    { genre: 'Hip hop', count: 2 },
    { genre: 'Classical', count: 2 },
    { genre: 'Rock', count: 2 },
    { genre: 'Indie', count: 2 }
  ];

  const width = 500, height = 500, radius = Math.min(width, height) / 2;
  const color = d3.scale.category20();
  const arc = d3.svg.arc().outerRadius(radius - 10).innerRadius(0);
  const labelArc = d3.svg.arc().outerRadius(radius - 60).innerRadius(radius - 60);
  const pie = d3.layout.pie().sort(null).value(d => d.count);
  const total = d3.sum(genreData, d => d.count);

  const svg = d3.select("#genre-pie-chart")
    .append("svg")
    .attr("width", width)
    .attr("height", height)
    .append("g")
    .attr("transform", `translate(${width / 2},${height / 2})`);

  const tooltip = d3.select("body").append("div")
    .attr("class", "tooltip")
    .style("opacity", 0)
    .style("position", "absolute")
    .style("background", "#222")
    .style("color", "#fff")
    .style("padding", "6px 10px")
    .style("border-radius", "4px")
    .style("font-size", "0.85rem")
    .style("pointer-events", "none");

  const g = svg.selectAll(".arc")
    .data(pie(genreData))
    .enter().append("g")
    .attr("class", "arc");

  g.append("path")
    .attr("fill", d => color(d.data.genre))
    .transition()
    .duration(1000)
    .attrTween("d", function (d) {
      const i = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
      return t => arc(i(t));
    });

  g.selectAll("path")
    .on("mouseover", function (event, d) {
      const count = d.data.count;
      const genre = d.data.genre;
      const percentage = ((count / total) * 100).toFixed(1);
      tooltip.html(`<strong>${genre}</strong><br>${count} tracks (${percentage}%)`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px")
        .transition().duration(200).style("opacity", 0.95);
    })
    .on("mousemove", function (event) {
      tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", function () {
      tooltip.transition().duration(200).style("opacity", 0);
    });

  g.append("text")
    .transition()
    .delay(1000)
    .duration(500)
    .attr("transform", d => `translate(${labelArc.centroid(d)})`)
    .attr("dy", ".35em")
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text(d => {
      const genre = d.data.genre;
      const percentage = ((d.data.count / total) * 100).toFixed(1);
      return `${genre} (${percentage}%)`;
    });
}

function initGenrePieChart() {
  let triggered = false;

  const observer = new IntersectionObserver(entries => {
    if (!triggered && entries[0].isIntersecting) {
      triggered = true;
      renderGenrePieChart();
      observer.disconnect();
    }
  }, { threshold: 0.3 });

  observer.observe(document.querySelector("#genre-distribution"));
}

initGenrePieChart();
