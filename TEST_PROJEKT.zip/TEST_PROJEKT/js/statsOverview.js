function animateCount(el, endValue, duration = 1000) {
  const start = 0;
  const increment = endValue / (duration / 16);
  let current = 0;

  function update() {
    current += increment;
    if (current >= endValue) {
      el.textContent = endValue.toLocaleString();
    } else {
      el.textContent = Math.floor(current).toLocaleString();
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

d3.json("data/streamingHistory_music_0.json", function (error, data) {
  if (error) throw error;

  const totalStreams = data.length;
  const totalMinutes = Math.round(d3.sum(data, d => d.msPlayed || d.ms_played || 0) / 60000);
  const totalSongs = d3.set(data.map(d => d.trackName || d.master_metadata_track_name)).values().length;
  const totalArtists = d3.set(data.map(d => d.artistName || d.master_metadata_album_artist_name)).values().length;

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCount(document.getElementById("stat-streams"), totalStreams);
        animateCount(document.getElementById("stat-minutes"), totalMinutes);
        animateCount(document.getElementById("stat-songs"), totalSongs);
        animateCount(document.getElementById("stat-artists"), totalArtists);
        observer.disconnect(); // Run once
      }
    });
  }, { threshold: 0.5 });

  observer.observe(document.querySelector("#stats-overview"));
});
