function loadStreamingHistory(callback) {
  d3.json("data/streamingHistory_music_0.json", function (error, rawData) {
    if (error) throw error;
    callback(rawData);
  });
}

loadStreamingHistory(function (rawData) {
  const trackStats = d3.nest()
    .key(d => {
      const track = d.trackName || d.master_metadata_track_name || "Unknown Track";
      const artist = d.artistName || d.master_metadata_album_artist_name || "Unknown Artist";
      return `${track} — ${artist}`;
    })
    .rollup(v => d3.sum(v, d => d.msPlayed || d.ms_played))
    .entries(rawData)
    .filter(d => !d.key.includes("Unknown"))
    .sort((a, b) => d3.descending(a.values, b.values))
    .slice(0, 10);

  const margin = { top: 20, right: 20, bottom: 60, left: 250 };
  const width = 900 - margin.left - margin.right;
  const height = trackStats.length * 40;

  const svg = d3.select("#top-tracks-chart")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

  const x = d3.scale.linear()
    .domain([0, d3.max(trackStats, d => d.values)])
    .range([0, width]);

  const y = d3.scale.ordinal()
    .domain(trackStats.map(d => d.key))
    .rangeRoundBands([0, height], 0.2);

  const xAxis = d3.svg.axis().scale(x).orient("bottom").ticks(5).tickFormat(d => `${Math.round(d / 60000)} min`);
  const yAxis = d3.svg.axis().scale(y).orient("left");

  svg.append("g")
    .attr("class", "x axis")
    .attr("transform", `translate(0,${height})`)
    .call(xAxis)
    .append("text")
    .attr("x", width / 2)
    .attr("y", 40)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Listening Time (minutes)");

  svg.append("g")
    .attr("class", "y axis")
    .call(yAxis)
    .append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", -margin.left + 20)
    .attr("x", -height / 2)
    .style("text-anchor", "middle")
    .style("fill", "white")
    .text("Track");

  const tooltip = d3.select("body").append("div")
    .attr("class", "tooltip")
    .style("opacity", 0);

  const bars = svg.selectAll(".bar")
    .data(trackStats)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("y", d => y(d.key))
    .attr("height", y.rangeBand())
    .attr("x", 0)
    .attr("width", 0)
    .attr("fill", "#1db954")
    .style("opacity", 0)
    .on("mouseover", function (event, d) {
      tooltip.transition().duration(200).style("opacity", 0.9);
      tooltip
        .html(`<strong>${d.key}</strong><br>${Math.round(d.values / 60000)} minutes`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px");
      d3.select(this).attr("fill", "#1ed760");
    })
    .on("mouseout", function () {
      tooltip.transition().duration(200).style("opacity", 0);
      d3.select(this).attr("fill", "#1db954");
    })
    .on("click", function () {
      const randomFeatures = {
        danceability: Math.random(),
        energy: Math.random(),
        valence: Math.random(),
        acousticness: Math.random(),
        instrumentalness: Math.random(),
        liveness: Math.random(),
        speechiness: Math.random(),
        tempo: Math.random() * 250
      };
      if (typeof renderRadarChart === 'function') {
        renderRadarChart(randomFeatures, true);
      }
    });

  const labels = svg.selectAll(".label")
    .data(trackStats)
    .enter()
    .append("text")
    .attr("x", 0)
    .attr("y", d => y(d.key) + y.rangeBand() / 2)
    .attr("dy", ".35em")
    .attr("fill", "white")
    .style("opacity", 0)
    .text(d => `${Math.round(d.values / 60000)} min`);

  // Scroll-triggered observer
  const section = document.querySelector("#top-tracks");

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        bars.transition()
          .duration(800)
          .delay((d, i) => i * 100)
          .attr("width", d => x(d.values))
          .style("opacity", 1);

        labels.transition()
          .duration(800)
          .delay((d, i) => i * 100 + 400)
          .attr("x", d => x(d.values) + 5)
          .style("opacity", 1);

        observer.disconnect();
      }
    });
  }, { threshold: 0.4 });

  observer.observe(section);
});
